{
  "plugins": [ "plugins/markdown" ],
  "markdown": {
    "parser": "gfm"
  }
}
